<?php 
  include("Persona4.php");
class Empleado11 extends Persona4{
    private int $sueldo = 0;
    public static $SUELDO_TOP = 33333;
    private array $numeros;

    public function __construct(string $name, string $surname,$year, int $sueldo, array $tlfn_array){
       
        parent::__construct($name, $surname,$year);
        $this-> setsueldo($sueldo);
        $this-> setNumeros($tlfn_array);


    }

    public function getSueldo()
    {
        return $this->sueldo;
    }

    public function setSueldo($sueldo)
    {
        $this->sueldo = $sueldo;

        if($this->sueldo == 0)

        $this->sueldo = 1000;

        return $this;
    }

   
    public function getNumeros()
    {
        
        return $this->numeros;
    }

    public function setNumeros($numeros)
    {
        $this->numeros = $numeros;

        return $this;
    }

     /**
     * Get the value of SUELDO_TOP
     */ 
    public function getSUELDO_TOP()
    {
        return self::$SUELDO_TOP;
    }


    public static function setSUELDO_TOP($SUELDO_TOP)
    {
        self::$SUELDO_TOP = $SUELDO_TOP;

    }


    public function getNombreCompleto() : string{
            $nombreCompleto = "";
            $nombreCompleto = parent::getNombre() ." ". parent::getApellidos();

            return $nombreCompleto;
    }


    public  function anyadirTelefono(int $telefono){
        $this->setNumeros($telefono);
    }

    public  function listarTelefonos() : string{
        
        $array = $this->getNumeros();
        $string = "";
        for ($i=0; $i < count($this->numeros); $i++) { 
            $string = "<ul><li>".implode("<li>",$array[$i])."</li></ul>";
        }

        return $string;

    }

    public  function vaciarTelefonos(int $telefono){

       $telefonos =  $this->getNumeros();

        unset($telefonos);


        $telefonos = "";

        echo $telefonos;
    }

    public function debePagarImpuestos() :bool{

        $bool = false;


        if($this->getSueldo() > self::$SUELDO_TOP || parent::getEdad() >=  21){
            $bool = true;
            echo"Deber pagar impuestos ☺ ";
        }
        else{
        echo "No debe pagar impuestos ";
        }
        return $bool;
    }

    public static function toHtml(Persona4 $p4): string {
        if ($p4 instanceof Empleado11) {
            return "Empleado : ". $p4->getNombreCompleto()."<br><br> Sueldo y Sueldo Top :<br>".$p4->getSueldo()." <br> ".$p4->getSUELDO_TOP()."<br><br> Telefonos :<br>". $p4->listarTelefonos();

        }else{
            return "Persona : ". $p4->getNombreCompleto();
        }
    }


    public function __toString() : string{

        $string = $this->getNombreCompleto().", que es un empleado con los siguientes datos: "
                                    ."<br><br><ul><li>Edad : ". 
                                        $this->getEdad()
                                    ."<br><br></li> <li>Sueldo / Sueldo Top : ".
                                        $this->getSueldo(). " / " . $this->getSUELDO_TOP()
                                    ."<br><br></li> Tiene como teléfonos : ".
                                        $this->listarTelefonos()
                                    ."</ul> <br>".$this->debePagarImpuestos();


        return $string;
    }
}  

    $tlfn[] = [644428371,954405960,615222333514];

    $empleado11 = new Empleado11($persona4->getNombre(),$persona4->getApellidos(),$persona4->getEdad(),0,$tlfn);

    echo $empleado11->__toString();
?>