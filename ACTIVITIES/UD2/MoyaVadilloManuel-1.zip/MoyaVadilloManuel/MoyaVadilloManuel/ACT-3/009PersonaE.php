<?php 
  include("Persona2.php");
class Empleado9 extends Persona2{
    private int $sueldo = 0;
    public static $SUELDO_TOP = 33333;
    private array $numeros;

    public function __construct(string $name, string $surname,$year, int $sueldo, array $tlfn_array){
       
        parent::__construct($name, $surname,$year);
        $this-> setsueldo($sueldo);
        $this-> setNumeros($tlfn_array);


    }

    public function getSueldo()
    {
        return $this->sueldo;
    }

    public function setSueldo($sueldo)
    {
        $this->sueldo = $sueldo;

        if($this->sueldo == 0)

        $this->sueldo = 1000;

        return $this;
    }

   
    public function getNumeros()
    {
        
        return $this->numeros;
    }

    public function setNumeros($numeros)
    {
        $this->numeros = $numeros;

        return $this;
    }

     /**
     * Get the value of SUELDO_TOP
     */ 
    public function getSUELDO_TOP()
    {
        return self::$SUELDO_TOP;
    }


    public static function setSUELDO_TOP($SUELDO_TOP)
    {
        self::$SUELDO_TOP = $SUELDO_TOP;

    }


    public function getNombreCompleto() : string{
            $nombreCompleto = "";
            $nombreCompleto = parent::getNombre() ." ". parent::getApellidos();

            return $nombreCompleto;
    }


    public  function anyadirTelefono(int $telefono){
        $this->setNumeros($telefono);
    }

    public  function listarTelefonos() : string{
        
        $array = $this->getNumeros();
        $string = "";
        for ($i=0; $i < count($this->numeros); $i++) { 
            $string = "<ul><li>".implode("<li>",$array[$i])."</li></ul>";
        }

        return $string;

    }

    public  function vaciarTelefonos(int $telefono){

       $telefonos =  $this->getNumeros();

        unset($telefonos);


        $telefonos = "";

        echo $telefonos;
    }

    public function debePagarImpuestos() :bool{

        $bool = false;


        if($this->getSueldo() > self::$SUELDO_TOP || parent::getEdad() >=  21){
            $bool = true;
            echo"Deber pagar impuestos ☺";
        }
        else
        echo "No debe pagar impuestos";

        return $bool;
    }

    public static function toHtml(Persona2 $p2): string {
        if ($p2 instanceof Empleado9) {
            return "Empleado : ". $p2->getNombreCompleto()."<br><br> Sueldo y Sueldo Top :<br>".$p2->getSueldo()." <br> ".$p2->getSUELDO_TOP()."<br><br> Telefonos :<br>". $p2->listarTelefonos();

        }else{
            return "Persona : ". $p2->getNombreCompleto();
        }
    }
}

    $tlfn[] = [644428371,954405960,615222333514];

    $empleado9 = new Empleado9($persona2->getNombre(),$persona2->getApellidos(),$persona2->getEdad(),0,$tlfn);

    echo $empleado9->debePagarImpuestos();
?>