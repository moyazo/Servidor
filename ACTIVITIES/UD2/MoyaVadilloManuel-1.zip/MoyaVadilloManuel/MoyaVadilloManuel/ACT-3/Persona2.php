<?php 

class Persona2{


    protected string $nombre ="";
    protected string $Apellidos = "";

    protected int $edad = 0;

    public function __construct(string $name, string $surname, int $year){
        $this-> nombre = $name;
        $this-> Apellidos = $surname;
        $this-> edad = $year;
    }

    public function getNombre()
    {
            return $this->nombre;
    }

    public function setNombre($nombre)
    {
            $this->nombre = $nombre;

            return $this;
    }

     
    public function getApellidos()
    {
            return $this->Apellidos;
    }

    
    public function setApellidos($Apellidos)
    {
            $this->Apellidos = $Apellidos;

            return $this;
    }

     /**
     * Get the value of edad
     */ 
    public function getEdad()
    {
        return $this->edad;
    }

   
    public function setEdad($edad)
    {
        $this->edad = $edad;

        return $this;
    }

    public function getNombreCompleto() : string{
        $nombreCompleto = "";
        $nombreCompleto = $this->nombre ." ". $this->Apellidos;

        return $nombreCompleto;
}

    public static function toHtml(Persona2 $p2): string{

        return "La persona se llama : ". $p2->getNombreCompleto();
         
     
    }

   
}
$persona2 = new Persona2("Manuel","Moya Vadillo",21);

?>