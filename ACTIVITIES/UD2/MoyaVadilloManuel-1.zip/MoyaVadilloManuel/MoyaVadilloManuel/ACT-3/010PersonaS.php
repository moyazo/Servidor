<?php 
  include("Persona3.php");
class Empleado9 extends Persona3{
    private int $sueldo = 0;
    public static $SUELDO_TOP = 33333;
    private array $numeros;

    public function __construct(string $name, string $surname,$year, int $sueldo, array $tlfn_array){
       
        parent::__construct($name, $surname,$year);
        $this-> setsueldo($sueldo);
        $this-> setNumeros($tlfn_array);


    }

    public function getSueldo()
    {
        return $this->sueldo;
    }

    public function setSueldo($sueldo)
    {
        $this->sueldo = $sueldo;

        if($this->sueldo == 0)

        $this->sueldo = 1000;

        return $this;
    }

   
    public function getNumeros()
    {
        
        return $this->numeros;
    }

    public function setNumeros($numeros)
    {
        $this->numeros = $numeros;

        return $this;
    }

     /**
     * Get the value of SUELDO_TOP
     */ 
    public function getSUELDO_TOP()
    {
        return self::$SUELDO_TOP;
    }


    public static function setSUELDO_TOP($SUELDO_TOP)
    {
        self::$SUELDO_TOP = $SUELDO_TOP;

    }


    public function getNombreCompleto() : string{
            $nombreCompleto = "";
            $nombreCompleto = parent::getNombre() ." ". parent::getApellidos();

            return $nombreCompleto;
    }


    public  function anyadirTelefono(int $telefono){
        $this->setNumeros($telefono);
    }

    public  function listarTelefonos() : string{
        
        $array = $this->getNumeros();
        $string = "";
        for ($i=0; $i < count($this->numeros); $i++) { 
            $string = "<ul><li>".implode("<li>",$array[$i])."</li></ul>";
        }

        return $string;

    }

    public  function vaciarTelefonos(int $telefono){

       $telefonos =  $this->getNumeros();

        unset($telefonos);


        $telefonos = "";

        echo $telefonos;
    }

    public function debePagarImpuestos() :bool{

        $bool = false;


        if($this->getSueldo() > self::$SUELDO_TOP || parent::getEdad() >=  21){
            $bool = true;
            echo"Deber pagar impuestos ☺ ";
        }
        else{
        echo "No debe pagar impuestos ";
        }
        return $bool;
    }

    public static function toHtml(Persona3 $p3): string {
        if ($p3 instanceof Empleado9) {
            return "Empleado : ". $p3->getNombreCompleto()."<br><br> Sueldo y Sueldo Top :<br>".$p3->getSueldo()." <br> ".$p3->getSUELDO_TOP()."<br><br> Telefonos :<br>". $p3->listarTelefonos();

        }else{
            return "Persona : ". $p3->getNombreCompleto();
        }
    }


    public function __toString() : string{

        $string = $this->getNombreCompleto().", que es un empleado con los siguientes datos: "
                                    ."<br><br><ul><li>Edad : ". 
                                        $this->getEdad()
                                    ."<br><br></li> <li>Sueldo / Sueldo Top : ".
                                        $this->getSueldo(). " / " . $this->getSUELDO_TOP()
                                    ."<br><br></li> Tiene como teléfonos : ".
                                        $this->listarTelefonos()
                                    ."</ul> <br>".$this->debePagarImpuestos();


        return $string;
    }
}  

    $tlfn[] = [644428371,954405960,615222333514];

    $empleado10 = new Empleado9($persona3->getNombre(),$persona3->getApellidos(),$persona3->getEdad(),0,$tlfn);

    echo $empleado10->__toString();
?>