<?php 

class Empleado2{

    private string $nombre ="";
    private string $Apellidos = "";
    private int $sueldo = 0;

    private array $numeros;

    public function __construct(string $name, string $surname, int $sueldo, array $tlfn_array){

        $this-> nombre = $name;
        $this-> Apellidos = $surname;
        $this-> setsueldo($sueldo);
        $this-> setNumeros($tlfn_array);

    }
    

    public function getSueldo()
    {
        return $this->sueldo;
    }

    public function setSueldo($sueldo)
    {
        $this->sueldo = $sueldo;

        if($this->sueldo == 0)

        $this->sueldo = 1000;

        return $this;
    }

   
    public function getNumeros()
    {
        
        return $this->numeros;
    }

    public function setNumeros($numeros)
    {
        $this->numeros = $numeros;

        return $this;
    }

    public function getNombreCompleto() : string{
            $nombreCompleto = "";
            $nombreCompleto = $this->nombre ." ". $this->Apellidos;

            return $nombreCompleto;
    }


    public  function anyadirTelefono(int $telefono){
        $this->setNumeros($telefono);
    }

    public  function listarTelefonos() : string{
        
        $array = $this->getNumeros();
        $string = "";
        for ($i=0; $i < count($this->numeros); $i++) { 
            $string = implode(",",$array[$i]);
        }

        return $string;

    }

    public  function vaciarTelefonos(int $telefono){

       $telefonos =  $this->getNumeros();

        unset($telefonos);


        $telefonos = "";

        echo $telefonos;
    }



    public function debePagarImpuestos(Empleado $e) :bool{

        $bool = false;

      if($e->getSueldo() > 3333)
        $bool = true;
        

        return $bool;
    }

    
}

    $tlfn[] = [644428371,954405960,615222333514];

    $empleado2 = new Empleado2("Manuel", "Moya Vadillo" , 0,$tlfn);

    echo $empleado2->getSueldo();
?>