<?php 
  include("Persona1.php");
class Empleado8 extends Persona1{
    private int $sueldo = 0;
    public static $SUELDO_TOP = 33333;
    private array $numeros;

    public function __construct(string $name, string $surname, int $sueldo, array $tlfn_array){
       
        parent::__construct($name, $surname);
        $this-> setsueldo($sueldo);
        $this-> setNumeros($tlfn_array);


    }

    public function getSueldo()
    {
        return $this->sueldo;
    }

    public function setSueldo($sueldo)
    {
        $this->sueldo = $sueldo;

        if($this->sueldo == 0)

        $this->sueldo = 1000;

        return $this;
    }

   
    public function getNumeros()
    {
        
        return $this->numeros;
    }

    public function setNumeros($numeros)
    {
        $this->numeros = $numeros;

        return $this;
    }

     /**
     * Get the value of SUELDO_TOP
     */ 
    public function getSUELDO_TOP()
    {
        return self::$SUELDO_TOP;
    }


    public static function setSUELDO_TOP($SUELDO_TOP)
    {
        self::$SUELDO_TOP = $SUELDO_TOP;

    }


    public function getNombreCompleto() : string{
            $nombreCompleto = "";
            $nombreCompleto = parent::getNombre() ." ". parent::getApellidos();

            return $nombreCompleto;
    }


    public  function anyadirTelefono(int $telefono){
        $this->setNumeros($telefono);
    }

    public  function listarTelefonos() : string{
        
        $array = $this->getNumeros();
        $string = "";
        for ($i=0; $i < count($this->numeros); $i++) { 
            $string = "<ul><li>".implode("<li>",$array[$i])."</li></ul>";
        }

        return $string;

    }

    public  function vaciarTelefonos(int $telefono){

       $telefonos =  $this->getNumeros();

        unset($telefonos);


        $telefonos = "";

        echo $telefonos;
    }

    public function debePagarImpuestos(Empleado $e) :bool{

        $bool = false;

      if($e->getSueldo() > $this->SUELDO_TOP)
        $bool = true;
        

        return $bool;
    }

    public static function toHtml(Persona1 $p1): string {
        if ($p1 instanceof Empleado8) {
            return "Empleado : ". $p1->getNombreCompleto()."<br><br> Sueldo y Sueldo Top :<br>".$p1->getSueldo()." <br> ".$p1->getSUELDO_TOP()."<br><br> Telefonos :<br>". $p1->listarTelefonos();

        }else{
            return "Persona : ". $p1->getNombreCompleto();
        }
    }
}

    $tlfn[] = [644428371,954405960,615222333514];

    $empleado8 = new Empleado8($persona1->getNombre(),$persona1->getApellidos(),0,$tlfn);

    echo $empleado8->tohtml($empleado8);
?>