<?php 

class Persona3{


    protected string $nombre ="";
    protected string $Apellidos = "";

    protected int $edad = 0;

    public function __construct(string $name, string $surname, int $year){
        $this-> nombre = $name;
        $this-> Apellidos = $surname;
        $this-> edad = $year;
    }

    public function getNombre()
    {
            return $this->nombre;
    }

    public function setNombre($nombre)
    {
            $this->nombre = $nombre;

            return $this;
    }

     
    public function getApellidos()
    {
            return $this->Apellidos;
    }

    
    public function setApellidos($Apellidos)
    {
            $this->Apellidos = $Apellidos;

            return $this;
    }

     /**
     * Get the value of edad
     */ 
    public function getEdad()
    {
        return $this->edad;
    }

   
    public function setEdad($edad)
    {
        $this->edad = $edad;

        return $this;
    }

    public function getNombreCompleto() : string{
        $nombreCompleto = "";
        $nombreCompleto = $this->nombre ." ". $this->Apellidos;

        return $nombreCompleto;
}

    public static function toHtml(Persona3 $p3): string{

        return "La persona se llama : ". $p3->getNombreCompleto();
         
     
    }

   
}
$persona3 = new Persona3("Manuel","Moya Vadillo",18);

?>