<?php 

class Persona1{


    protected string $nombre ="";
    protected string $Apellidos = "";

    public function __construct(string $name, string $surname){
        $this-> nombre = $name;
        $this-> Apellidos = $surname;
    }

    public function getNombre()
    {
            return $this->nombre;
    }

    public function setNombre($nombre)
    {
            $this->nombre = $nombre;

            return $this;
    }

     
    public function getApellidos()
    {
            return $this->Apellidos;
    }

    
    public function setApellidos($Apellidos)
    {
            $this->Apellidos = $Apellidos;

            return $this;
    }

    public function getNombreCompleto() : string{
        $nombreCompleto = "";
        $nombreCompleto = $this->nombre ." ". $this->Apellidos;

        return $nombreCompleto;
}

    public static function toHtml(Persona1 $p1): string{

        return "La persona se llama : ". $p1->getNombreCompleto();
         
     
    }
}
$persona1 = new Persona1("Manuel","Moya Vadillo");

?>