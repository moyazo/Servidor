<?php 

class Persona{


    protected string $nombre ="";
    protected string $Apellidos = "";

    public function __construct(string $name, string $surname){
        $this-> nombre = $name;
        $this-> Apellidos = $surname;
    }

    public function getNombre()
    {
            return $this->nombre;
    }

    public function setNombre($nombre)
    {
            $this->nombre = $nombre;

            return $this;
    }

     
    public function getApellidos()
    {
            return $this->Apellidos;
    }

    
    public function setApellidos($Apellidos)
    {
            $this->Apellidos = $Apellidos;

            return $this;
    }
}
$persona = new Persona("Manuel","Moya Vadillo");

?>