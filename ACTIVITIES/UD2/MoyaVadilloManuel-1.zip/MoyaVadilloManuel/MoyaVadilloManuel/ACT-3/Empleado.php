<?php 

class Empleado{

    private string $nombre ="";
    private string $Apellidos = "";
    private int $sueldo = 0;

    public function __construct(string $name, string $surname, int $sueldo){

        $this-> nombre = $name;
        $this-> Apellidos = $surname;
        $this-> sueldo = $sueldo;

    }
    
 
    public function getNombre()
    {
        return $this->nombre;
    }

    public function setNombre($nombre)
    {
        $this->nombre = $nombre;

        return $this;
    }
 
    public function getApellidos()
    {
        return $this->Apellidos;
    }

    public function setApellidos($Apellidos)
    {
        $this->Apellidos = $Apellidos;

        return $this;
    }

    public function getSueldo()
    {
        return $this->sueldo;
    }

    public function setSueldo($sueldo)
    {
        $this->sueldo = $sueldo;

        return $this;
    }

    public function getNombreCompleto(Empleado $e) : string{
            $nombreCompleto = "";
            $nombreCompleto = $e->getNombre() ." ". $e->getApellidos();

            return $nombreCompleto;
    }

    public function debePagarImpuestos(Empleado $e) :bool{

        $bool = false;

      if($e->getSueldo() > 3333)
        $bool = true;
        

        return $bool;
    }
}

    $empleado = new Empleado("Manuel", "Moya Vadillo" , 1);

    echo $empleado->getNombreCompleto($empleado);
?>