<?php 

echo "Primera forma de texto";
print("Segunda forma de texto");
// Cometario en linea
/* Comentario en bloque */

?>
<?= "Tercera Forma de texto <br><br>**********<br>Ejercicio 003";?>