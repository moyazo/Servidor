<?php 

for ($i=0; $i < 51; $i++) { 
    if($i%2 == 0){
        print("<ul><li>".$i."</li></ul>"); // SI PONEMOS LAS ETIQUETAS DE HTML DE UNA LISTA OBTENDREMOS DICHA LISTA
    }else{
        
    }
}

?>